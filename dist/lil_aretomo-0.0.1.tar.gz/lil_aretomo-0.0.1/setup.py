import setuptools

setuptools.setup(use_scm_version={"write_to": "lil_aretomo/_version.py"})
